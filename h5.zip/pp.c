#include<unistd.h>
#include<time.h>
#include <stdlib.h> 
#include <stdio.h> 
#include <string.h> 
#include "mpi.h"

int main(int argc, char **argv) {
    int procid, numprocs;

    MPI_Status status;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &procid);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);

    time_t t;
    int partners[numprocs], partner = -1, variables = numprocs - 1;

    srand(time(NULL) + procid * numprocs);

    for(int i = 0; i < numprocs; i++)   partners[i] = 0;

    if (procid == 0) {
        int randomchoice = (rand() % (numprocs - 1) + 1);
        printf("Teacher says: Student %d start!\n",randomchoice);

        MPI_Send(partners, numprocs, MPI_INT, randomchoice, 0,MPI_COMM_WORLD);
        MPI_Recv(partners, numprocs, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);

        for(int i = 0; i < numprocs; i++)
            printf("partners[%d] %d\n",i, partners[i]);
    }
    else {
        MPI_Recv(partners, numprocs, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);

        int rem = 0, choice, choice1, partner, sendto;
        int preference[numprocs - 1];
        int myself = 0;

        for(int i = 1; i < numprocs; i++){
                if(i == procid)
                    myself = 1;
                else if(partners[i] == procid) 
                    partners[procid] = i; 
                else if(partners[i] == 0){
                    preference[rem] = i;
                    rem += 1;
                }
            }
        if(rem == 0){
            if(myself == 1)
                partners[procid] = procid;
            MPI_Send(partners, numprocs, MPI_INT, 0, 0,MPI_COMM_WORLD);}
        else{
            printf("hello\n");
            choice = rand() % rem;
            partner = preference[choice];
            printf("pid %d:choice %d partner %d\n",procid,choice,partner);
            partners[procid] = partner;
            partners[partner] = procid;
            
            rem = 0;
            for(int i = 1; i < numprocs; i++){
                if(partners[i]==0) {
                    preference[rem];
                    rem += 1;
                }
            }
            printf("rem %d\n", rem);
            if( rem != 0){
                choice1 = choice;
                while(choice1 == choice)
                    choice1 = rand() % rem;
                sendto = preference[choice1];
            }
            else sendto = 0;
            MPI_Send(partners, numprocs, MPI_INT, sendto, 0,MPI_COMM_WORLD);
        }
        printf("YO %d\n",procid);
    }

    MPI_Finalize();
}